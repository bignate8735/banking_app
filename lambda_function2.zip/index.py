import json
import boto3
from botocore.exceptions import ClientError

# Initialize the S3 client
s3_client = boto3.client('s3')

def lambda_handler(event, context):
    # Define the S3 bucket and the file name (JSON file)
    bucket_name = 'balancebucket8735'
    file_key = 'accountBalance.json'

    try:
        # Log the event for debugging
        print("Event:", json.dumps(event))

        # Extract relevant attributes from the context object
        context_info = {
            "function_name": context.function_name,
            "memory_limit_in_mb": context.memory_limit_in_mb,
            "function_version": context.function_version,
            "invoked_function_arn": context.invoked_function_arn,
            "aws_request_id": context.aws_request_id
        }
        print("Context Info:", json.dumps(context_info))

        # Retrieve the JSON file from S3
        print(f"Fetching file '{file_key}' from bucket '{bucket_name}'")
        response = s3_client.get_object(Bucket=bucket_name, Key=file_key)

        # Read and decode the JSON file content
        file_content = response['Body'].read().decode('utf-8')
        print(f"File content: {file_content}")

        # Parse the JSON content
        account_data = json.loads(file_content)
        print(f"Parsed account data: {account_data}")

        # Return the account data as the response
        return {
            'statusCode': 200,
            'body': json.dumps(account_data),
            'headers': {
                'Content-Type': 'application/json'
            }
        }

    except ClientError as e:
        # Handle errors related to S3 (e.g., file not found or permission issue)
        error_message = f"Error retrieving file from S3: {str(e)}"
        print(error_message)
        return {
            'statusCode': 500,
            'body': json.dumps({'error': error_message}),
            'headers': {
                'Content-Type': 'application/json'
            }
        }

    except json.JSONDecodeError as e:
        # Handle errors in JSON decoding
        error_message = f"Error decoding JSON file: {str(e)}"
        print(error_message)
        return {
            'statusCode': 500,
            'body': json.dumps({'error': error_message}),
            'headers': {
                'Content-Type': 'application/json'
            }
        }

    except Exception as e:
        # Handle unexpected errors
        error_message = f"Unexpected error: {str(e)}"
        print(error_message)
        return {
            'statusCode': 500,
            'body': json.dumps({'error': error_message}),
            'headers': {
                'Content-Type': 'application/json'
            }
        }
